using UnityEngine;
using UnityEditor;
using System;

namespace Unity.MCP.Editor
{
    /// <summary>
    /// Unity 2023.2兼容性验证类
    /// </summary>
    public static class Unity2023Compatibility
    {
        // 菜单项已移至McpTestWindow.cs中定义
        // 避免重复定义导致的冲突
    }
}